import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:outliner/provider/auth.dart';
import 'package:outliner/provider/theme.dart';
import 'package:outliner/screen/main_screen.dart';
import 'package:outliner/screen/signin.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const EntryPoint());
}

class EntryPoint extends StatelessWidget {
  const EntryPoint({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CustomAuthProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) {
          return MaterialApp(
            title: 'Outliner',
            theme: ThemeData(
              primarySwatch: Colors.blue,
            ),
            darkTheme: ThemeData.dark(),
            themeMode: themeProvider.themeMode,
            home: Consumer<CustomAuthProvider>(
              builder: (context, authProvider, _) {
                return Scaffold(
                  body: authProvider.user == null
                      ? const Signin()
                      : const MainScreen(),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
