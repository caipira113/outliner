import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:outliner/widgets/custom_avatar.dart';
import 'package:outliner/widgets/timeline_widget.dart';

import '../service/user_service.dart';

class CommonProfileScreen extends StatefulWidget {
  final String userId;
  final bool isCurrentUser;

  const CommonProfileScreen({
    super.key,
    required this.userId,
    required this.isCurrentUser,
  });

  @override
  _CommonProfileScreenState createState() => _CommonProfileScreenState();
}

class _CommonProfileScreenState extends State<CommonProfileScreen> {
  final UserService _userService = UserService();
  late Future<DocumentSnapshot> _userDataFuture;
  File? _imageFile;

  @override
  void initState() {
    super.initState();
    _userDataFuture = _userService.getUserDoc(widget.userId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          if (widget.isCurrentUser)
            IconButton(
              icon: const Icon(Icons.logout),
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
            ),
        ],
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: _userDataFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return const Center(child: Text('Error loading profile.'));
          }

          final userData = snapshot.data!.data() as Map<String, dynamic>;
          return DefaultTabController(
            length: 3,
            child: NestedScrollView(
                headerSliverBuilder: (context, innerBoxIsScrolled) => [
                      SliverToBoxAdapter(
                        child: Column(
                          children: [
                            const SizedBox(height: 20),
                            _buildProfilePicture(userData['profilePictureUrl'],
                                userData['username']),
                            const SizedBox(height: 16),
                            Text(
                              userData['name'] ?? userData['username'],
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 24),
                            ),
                            Text(userData['username'] ?? 'Unknown User'),
                            const SizedBox(height: 16),
                            _buildFollowInfo(userData['following'] ?? 0,
                                userData['follower'] ?? 0),
                            if (widget.isCurrentUser) ...[
                              const SizedBox(height: 16),
                              ElevatedButton(
                                onPressed: () {
                                  // Implement profile editing functionality
                                },
                                child: const Text('Edit Profile'),
                              ),
                            ],
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                      SliverPersistentHeader(
                        delegate: _SliverAppBarDelegate(
                          const TabBar(
                            tabs: [
                              Tab(text: 'Posts'),
                              Tab(text: 'Replies'),
                              Tab(text: 'Media'),
                            ],
                          ),
                        ),
                        pinned: true,
                      ),
                    ],
                body: Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: TabBarView(
                    children: [
                      TimelineWidget(
                        userId: widget.userId,
                        filter: PostFilter.all,
                      ),
                      TimelineWidget(
                        userId: widget.userId,
                        filter: PostFilter.replies,
                      ),
                      TimelineWidget(
                        userId: widget.userId,
                        filter: PostFilter.media,
                      ),
                    ],
                  ),
                )),
          );
        },
      ),
    );
  }

  Widget _buildProfilePicture(String? profilePictureUrl, String username) {
    return GestureDetector(
      onTap: _pickImage,
      child: CircleAvatar(
        radius: 50,
        backgroundColor: Colors.grey[200],
        child: profilePictureUrl != null
            ? ClipOval(
                child: Image.network(
                  profilePictureUrl,
                  fit: BoxFit.cover,
                  width: 100,
                  height: 100,
                ),
              )
            : CustomAvatar(
                userId: widget.userId,
                username: username,
                size: 100,
              ),
      ),
    );
  }

  Widget _buildFollowInfo(int following, int follower) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildFollowColumn(following, 'Following'),
        const SizedBox(width: 24),
        _buildFollowColumn(follower, 'Followers'),
      ],
    );
  }

  Widget _buildFollowColumn(int count, String label) {
    return Column(
      children: [
        Text(
          count.toString(),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Text(label),
      ],
    );
  }

  Future<void> _pickImage() async {
    if (!widget.isCurrentUser) return;
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
      await _userService.updateProfilePicture(widget.userId, _imageFile!);
      setState(() {
        _userDataFuture = _userService.getUserDoc(widget.userId);
      });
    }
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  _SliverAppBarDelegate(this._tabBar);

  final TabBar _tabBar;

  @override
  double get minExtent => _tabBar.preferredSize.height;

  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}
