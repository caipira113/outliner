import 'package:cloud_firestore/cloud_firestore.dart';

class Follow {
  String followerId; // 팔로우하는 사용자 ID
  String followingId; // 팔로우되는 사용자 ID
  Timestamp timestamp;

  Follow({
    required this.followerId,
    required this.followingId,
    required this.timestamp,
  });

  // Firestore에서 DocumentSnapshot을 Follow 객체로 변환하는 팩토리 생성자
  factory Follow.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return Follow(
      followerId: data['followerId'] ?? '',
      followingId: data['followingId'] ?? '',
      timestamp: data['timestamp'] as Timestamp,
    );
  }

  // Follow 객체를 Firestore에 저장할 수 있는 형식으로 변환하는 메서드
  Map<String, dynamic> toMap() {
    return {
      'followerId': followerId,
      'followingId': followingId,
      'timestamp': timestamp,
    };
  }
}
