import 'package:cloud_firestore/cloud_firestore.dart';

class UserProfile {
  String id;
  String? name;
  String username;
  String? profilePictureUrl;
  Timestamp createdAt;
  int following;
  int follower;

  UserProfile(
      {required this.id,
      this.name,
      required this.username,
      this.profilePictureUrl,
      required this.createdAt,
      required this.following,
      required this.follower});

  factory UserProfile.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return UserProfile(
        id: doc.id,
        name: data['name'] ?? data['username'],
        username: data['username'],
        profilePictureUrl: data['profilePictureUrl'],
        createdAt: data['createdAt'] as Timestamp,
        following: data['following'],
        follower: data['follower']);
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'username': username,
      'profilePictureUrl': profilePictureUrl,
      'createdAt': createdAt,
      'following': following,
      'follower': follower
    };
  }
}
