import 'package:cloud_firestore/cloud_firestore.dart';

import '../model/post.dart';

class TimelineRepository {
  final String userId;
  final int pageSize = 20;
  DocumentSnapshot? _lastDocument;
  bool _hasMorePosts = true;

  TimelineRepository(this.userId);

  Future<List<String>> getFollowingIds() async {
    // 팔로잉 목록을 가져오는 로직 구현
    // 예: return ['user1', 'user2', ...];
    return [];
  }

  Future<List<Post>> getTimelinePosts({bool refresh = false}) async {
    if (refresh) {
      _lastDocument = null;
      _hasMorePosts = true;
    }

    if (!_hasMorePosts) return [];

    final followingIds = await getFollowingIds();
    followingIds.add(userId); // 자신의 포스트도 포함

    Query query = FirebaseFirestore.instance
        .collection('posts')
        .where('userId', whereIn: followingIds)
        .orderBy('timestamp', descending: true)
        .limit(pageSize);

    if (_lastDocument != null) {
      query = query.startAfterDocument(_lastDocument!);
    }

    final snapshot = await query.get();
    if (snapshot.docs.isEmpty) {
      _hasMorePosts = false;
      return [];
    }

    _lastDocument = snapshot.docs.last;
    return snapshot.docs.map((doc) => Post.fromDocument(doc)).toList();
  }

  Stream<Post> getNewPosts() {
    return Stream.fromFuture(getFollowingIds()).asyncExpand((followingIds) {
      followingIds.add(userId);
      return FirebaseFirestore.instance
          .collection('posts')
          .where('userId', whereIn: followingIds)
          .orderBy('timestamp', descending: true)
          .limit(1)
          .snapshots()
          .map((snapshot) => snapshot.docs.isNotEmpty
              ? Post.fromDocument(snapshot.docs.first)
              : null)
          .where((post) => post != null)
          .cast<Post>();
    });
  }
}
