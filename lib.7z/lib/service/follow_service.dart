import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../model/follow.dart';

class FollowService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // 사용자를 팔로우하는 메서드
  Future<void> followUser(String followingId) async {
    final user = _auth.currentUser;
    if (user != null) {
      final follow = Follow(
        followerId: user.uid,
        followingId: followingId,
        timestamp: Timestamp.now(),
      );

      await _firestore.collection('follows').add(follow.toMap());
    }
  }

  // 사용자의 팔로우를 취소하는 메서드
  Future<void> unfollowUser(String followingId) async {
    final user = _auth.currentUser;
    if (user != null) {
      final followQuery = await _firestore
          .collection('follows')
          .where('followerId', isEqualTo: user.uid)
          .where('followingId', isEqualTo: followingId)
          .get();

      for (var doc in followQuery.docs) {
        await doc.reference.delete();
      }
    }
  }

  // 사용자가 특정 사용자를 팔로우하고 있는지 확인하는 메서드
  Future<bool> isFollowing(String userId) async {
    final user = _auth.currentUser;
    if (user != null) {
      final followQuery = await _firestore
          .collection('follows')
          .where('followerId', isEqualTo: user.uid)
          .where('followingId', isEqualTo: userId)
          .get();

      return followQuery.docs.isNotEmpty;
    }
    return false;
  }
}
